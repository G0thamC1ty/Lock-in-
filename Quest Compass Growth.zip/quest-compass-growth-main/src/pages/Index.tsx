import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Plus, Star, Calendar } from 'lucide-react';
import { useGameData } from '../hooks/useGameData';
import { HabitCard } from '../components/HabitCard';
import { SpiderChart } from '../components/SpiderChart';
import { ProgressCard } from '../components/ProgressCard';
import { AddHabitForm } from '../components/AddHabitForm';
import { AchievementBadge } from '../components/AchievementBadge';

const Index = () => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [activeTab, setActiveTab] = useState<'habits' | 'progress' | 'achievements'>('habits');
  
  const {
    habits,
    disciplines,
    progress,
    achievements,
    addHabit,
    editHabit,
    completeHabit,
    uncompleteHabit,
    deleteHabit
  } = useGameData();

  const todaysDate = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-6xl font-bold gradient-text mb-4">
            Level Up Your Life
          </h1>
          <p className="text-lg text-muted-foreground mb-2">
            Transform your habits into achievements
          </p>
          <p className="text-sm text-muted-foreground">
            {todaysDate}
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex justify-center mb-8">
          <div className="glass-card p-1 rounded-lg">
            <div className="flex gap-1">
              {[
                { id: 'habits', label: 'Habits', icon: Calendar },
                { id: 'progress', label: 'Progress', icon: Star },
                { id: 'achievements', label: 'Achievements', icon: Star }
              ].map(tab => {
                const Icon = tab.icon;
                return (
                  <Button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    variant={activeTab === tab.id ? 'default' : 'ghost'}
                    className={`${
                      activeTab === tab.id 
                        ? 'bg-game-purple hover:bg-game-purple/80' 
                        : 'hover:bg-white/5'
                    } transition-all`}
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {tab.label}
                  </Button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Content based on active tab */}
        {activeTab === 'habits' && (
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column - Habits */}
            <div className="lg:col-span-2 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-semibold text-white">
                  Today's Habits ({habits.filter(h => h.completedToday).length}/{habits.length})
                </h2>
                <Button
                  onClick={() => setShowAddForm(!showAddForm)}
                  className="bg-game-purple hover:bg-game-purple/80"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Habit
                </Button>
              </div>

              {showAddForm && (
                <AddHabitForm
                  disciplines={disciplines}
                  onAddHabit={(habit) => {
                    addHabit(habit);
                    setShowAddForm(false);
                  }}
                  onCancel={() => setShowAddForm(false)}
                />
              )}

              <div className="space-y-4">
                {habits.length === 0 ? (
                  <Card className="glass-card p-8 text-center">
                    <h3 className="text-xl font-semibold text-white mb-2">
                      Ready to start your journey?
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      Add your first habit and begin earning XP!
                    </p>
                    <Button
                      onClick={() => setShowAddForm(true)}
                      className="bg-game-purple hover:bg-game-purple/80"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Create Your First Habit
                    </Button>
                  </Card>
                ) : (
                  habits.map(habit => (
                    <HabitCard
                      key={habit.id}
                      habit={habit}
                      disciplines={disciplines}
                      onComplete={completeHabit}
                      onUncomplete={uncompleteHabit}
                      onEdit={editHabit}
                      onDelete={deleteHabit}
                    />
                  ))
                )}
              </div>
            </div>

            {/* Right Column - Progress */}
            <div className="space-y-6">
              <ProgressCard progress={progress} />
              
              <Card className="glass-card p-6">
                <h3 className="text-lg font-semibold text-white mb-4 text-center">
                  Discipline Progress
                </h3>
                <SpiderChart disciplines={disciplines} size={280} />
              </Card>
            </div>
          </div>
        )}

        {activeTab === 'progress' && (
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <ProgressCard progress={progress} />
              <Card className="glass-card p-6">
                <h3 className="text-lg font-semibold text-white mb-4 text-center">
                  Discipline Breakdown
                </h3>
                <div className="space-y-3">
                  {disciplines.map(discipline => (
                    <div key={discipline.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-4 h-4 rounded-full"
                          style={{ backgroundColor: discipline.color }}
                        />
                        <span className="text-white">{discipline.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-semibold" style={{ color: discipline.color }}>
                          Level {discipline.level}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {discipline.totalXP} XP
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
            
            <Card className="glass-card p-6">
              <h3 className="text-xl font-semibold text-white mb-6 text-center">
                Complete Discipline Chart
              </h3>
              <div className="flex justify-center">
                <SpiderChart disciplines={disciplines} size={400} />
              </div>
            </Card>
          </div>
        )}

        {activeTab === 'achievements' && (
          <div className="max-w-4xl mx-auto">
            <Card className="glass-card p-6 mb-6">
              <h2 className="text-2xl font-semibold gradient-text text-center mb-6">
                Achievements
              </h2>
              <div className="grid md:grid-cols-3 gap-4">
                {achievements.map(achievement => (
                  <AchievementBadge key={achievement.id} achievement={achievement} />
                ))}
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default Index;
