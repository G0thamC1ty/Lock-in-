export interface Habit {
  id: string;
  name: string;
  description?: string;
  difficulty: 'easy' | 'medium' | 'hard';
  disciplines: string[];
  frequency: 'daily' | 'weekly' | string[];
  streak: number;
  completedToday: boolean;
  completedDates: string[];
  createdAt: string;
  xpReward: number;
}

export interface HabitStats {
  weeklyCompletions: number;
  monthlyCompletions: number;
  yearlyCompletions: number;
  totalCompletions: number;
}

export interface Discipline {
  id: string;
  name: string;
  color: string;
  totalXP: number;
  level: number;
}

export interface UserProgress {
  totalXP: number;
  level: number;
  dailyXP: number;
  weeklyXP: number;
  completedHabitsToday: number;
  currentStreak: number;
  longestStreak: number;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
  requirement: number;
  progress: number;
}
