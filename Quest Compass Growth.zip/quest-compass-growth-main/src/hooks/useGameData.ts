import { useState, useEffect } from 'react';
import { Habit, Discipline, UserProgress, Achievement } from '../types/game';

const STORAGE_KEYS = {
  HABITS: 'gaming-habits',
  DISCIPLINES: 'gaming-disciplines',
  PROGRESS: 'gaming-progress',
  ACHIEVEMENTS: 'gaming-achievements'
};

const DEFAULT_DISCIPLINES: Discipline[] = [
  { id: '1', name: 'Health', color: '#10B981', totalXP: 0, level: 1 },
  { id: '2', name: 'Mind', color: '#8B5CF6', totalXP: 0, level: 1 },
  { id: '3', name: 'Career', color: '#3B82F6', totalXP: 0, level: 1 },
  { id: '4', name: 'Social', color: '#F59E0B', totalXP: 0, level: 1 },
  { id: '5', name: 'Creativity', color: '#EF4444', totalXP: 0, level: 1 }
];

const DEFAULT_PROGRESS: UserProgress = {
  totalXP: 0,
  level: 1,
  dailyXP: 0,
  weeklyXP: 0,
  completedHabitsToday: 0,
  currentStreak: 0,
  longestStreak: 0
};

const DEFAULT_ACHIEVEMENTS: Achievement[] = [
  {
    id: '1',
    name: 'First Steps',
    description: 'Complete your first habit',
    icon: '🌟',
    unlocked: false,
    requirement: 1,
    progress: 0
  },
  {
    id: '2',
    name: 'Streak Master',
    description: 'Maintain a 7-day streak',
    icon: '🔥',
    unlocked: false,
    requirement: 7,
    progress: 0
  },
  {
    id: '3',
    name: 'XP Hunter',
    description: 'Earn 100 total XP',
    icon: '⚡',
    unlocked: false,
    requirement: 100,
    progress: 0
  }
];

export const useGameData = () => {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [disciplines, setDisciplines] = useState<Discipline[]>(DEFAULT_DISCIPLINES);
  const [progress, setProgress] = useState<UserProgress>(DEFAULT_PROGRESS);
  const [achievements, setAchievements] = useState<Achievement[]>(DEFAULT_ACHIEVEMENTS);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedHabits = localStorage.getItem(STORAGE_KEYS.HABITS);
    const savedDisciplines = localStorage.getItem(STORAGE_KEYS.DISCIPLINES);
    const savedProgress = localStorage.getItem(STORAGE_KEYS.PROGRESS);
    const savedAchievements = localStorage.getItem(STORAGE_KEYS.ACHIEVEMENTS);

    if (savedHabits) setHabits(JSON.parse(savedHabits));
    if (savedDisciplines) setDisciplines(JSON.parse(savedDisciplines));
    if (savedProgress) setProgress(JSON.parse(savedProgress));
    if (savedAchievements) setAchievements(JSON.parse(savedAchievements));
  }, []);

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HABITS, JSON.stringify(habits));
  }, [habits]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DISCIPLINES, JSON.stringify(disciplines));
  }, [disciplines]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(progress));
  }, [progress]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achievements));
  }, [achievements]);

  const getXPForDifficulty = (difficulty: Habit['difficulty']): number => {
    switch (difficulty) {
      case 'easy': return 1;
      case 'medium': return 3;
      case 'hard': return 5;
      default: return 1;
    }
  };

  const calculateLevel = (xp: number): number => {
    return Math.floor(xp / 100) + 1;
  };

  const addHabit = (habitData: Omit<Habit, 'id' | 'streak' | 'completedToday' | 'completedDates' | 'createdAt' | 'xpReward'>) => {
    const newHabit: Habit = {
      ...habitData,
      id: Date.now().toString(),
      streak: 0,
      completedToday: false,
      completedDates: [],
      createdAt: new Date().toISOString(),
      xpReward: getXPForDifficulty(habitData.difficulty)
    };
    setHabits(prev => [...prev, newHabit]);
  };

  const editHabit = (updatedHabit: Habit) => {
    setHabits(prev => prev.map(habit => 
      habit.id === updatedHabit.id ? updatedHabit : habit
    ));
  };

  const updateHabitCompletion = (habitId: string, date: string, completed: boolean) => {
    setHabits(prev => prev.map(habit => {
      if (habit.id === habitId) {
        const updatedCompletedDates = completed 
          ? [...habit.completedDates.filter(d => d !== date), date]
          : habit.completedDates.filter(d => d !== date);
        
        const today = new Date().toISOString().split('T')[0];
        const isToday = date === today;
        
        return {
          ...habit,
          completedDates: updatedCompletedDates,
          completedToday: isToday ? completed : habit.completedToday
        };
      }
      return habit;
    }));
  };

  const completeHabit = (habitId: string) => {
    const today = new Date().toISOString().split('T')[0];
    
    setHabits(prev => prev.map(habit => {
      if (habit.id === habitId && !habit.completedToday) {
        const updatedHabit = {
          ...habit,
          completedToday: true,
          completedDates: [...habit.completedDates, today],
          streak: habit.streak + 1
        };

        // Award XP
        const xpGained = habit.xpReward;
        setProgress(prevProgress => {
          const newTotalXP = prevProgress.totalXP + xpGained;
          const newLevel = calculateLevel(newTotalXP);
          
          return {
            ...prevProgress,
            totalXP: newTotalXP,
            level: newLevel,
            dailyXP: prevProgress.dailyXP + xpGained,
            weeklyXP: prevProgress.weeklyXP + xpGained,
            completedHabitsToday: prevProgress.completedHabitsToday + 1,
            currentStreak: Math.max(prevProgress.currentStreak, updatedHabit.streak),
            longestStreak: Math.max(prevProgress.longestStreak, updatedHabit.streak)
          };
        });

        // Update discipline XP
        setDisciplines(prevDisciplines => 
          prevDisciplines.map(discipline => {
            if (habit.disciplines.includes(discipline.id)) {
              const newXP = discipline.totalXP + Math.floor(xpGained / habit.disciplines.length);
              return {
                ...discipline,
                totalXP: newXP,
                level: calculateLevel(newXP)
              };
            }
            return discipline;
          })
        );

        // Check achievements
        setAchievements(prevAchievements =>
          prevAchievements.map(achievement => {
            if (achievement.unlocked) return achievement;
            
            let newProgress = achievement.progress;
            if (achievement.id === '1') { // First Steps
              newProgress = 1;
            } else if (achievement.id === '2') { // Streak Master
              newProgress = Math.max(newProgress, updatedHabit.streak);
            }
            
            return {
              ...achievement,
              progress: newProgress,
              unlocked: newProgress >= achievement.requirement,
              unlockedAt: newProgress >= achievement.requirement ? new Date().toISOString() : undefined
            };
          })
        );

        return updatedHabit;
      }
      return habit;
    }));
  };

  const uncompleteHabit = (habitId: string) => {
    const today = new Date().toISOString().split('T')[0];
    
    setHabits(prev => prev.map(habit => {
      if (habit.id === habitId && habit.completedToday) {
        const updatedHabit = {
          ...habit,
          completedToday: false,
          completedDates: habit.completedDates.filter(date => date !== today),
          streak: Math.max(0, habit.streak - 1)
        };

        // Remove XP
        const xpLost = habit.xpReward;
        setProgress(prevProgress => {
          const newTotalXP = Math.max(0, prevProgress.totalXP - xpLost);
          const newLevel = calculateLevel(newTotalXP);
          
          return {
            ...prevProgress,
            totalXP: newTotalXP,
            level: newLevel,
            dailyXP: Math.max(0, prevProgress.dailyXP - xpLost),
            weeklyXP: Math.max(0, prevProgress.weeklyXP - xpLost),
            completedHabitsToday: Math.max(0, prevProgress.completedHabitsToday - 1),
            currentStreak: updatedHabit.streak
          };
        });

        // Remove discipline XP
        setDisciplines(prevDisciplines => 
          prevDisciplines.map(discipline => {
            if (habit.disciplines.includes(discipline.id)) {
              const newXP = Math.max(0, discipline.totalXP - Math.floor(xpLost / habit.disciplines.length));
              return {
                ...discipline,
                totalXP: newXP,
                level: calculateLevel(newXP)
              };
            }
            return discipline;
          })
        );

        return updatedHabit;
      }
      return habit;
    }));
  };

  const deleteHabit = (habitId: string) => {
    setHabits(prev => prev.filter(habit => habit.id !== habitId));
  };

  return {
    habits,
    disciplines,
    progress,
    achievements,
    addHabit,
    editHabit,
    completeHabit,
    uncompleteHabit,
    deleteHabit,
    updateHabitCompletion
  };
};
