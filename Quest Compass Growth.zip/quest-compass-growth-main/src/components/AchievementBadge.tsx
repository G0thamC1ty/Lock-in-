
import { Badge } from '@/components/ui/badge';
import { Achievement } from '../types/game';

interface AchievementBadgeProps {
  achievement: Achievement;
}

export const AchievementBadge = ({ achievement }: AchievementBadgeProps) => {
  return (
    <div className={`p-4 rounded-lg border transition-all duration-300 ${
      achievement.unlocked 
        ? 'bg-game-gold/20 border-game-gold/50 animate-pulse-glow' 
        : 'bg-gray-800/50 border-gray-600/50'
    }`}>
      <div className="text-center">
        <div className={`text-3xl mb-2 ${achievement.unlocked ? 'grayscale-0' : 'grayscale'}`}>
          {achievement.icon}
        </div>
        <h4 className={`font-semibold mb-1 ${
          achievement.unlocked ? 'text-game-gold' : 'text-gray-400'
        }`}>
          {achievement.name}
        </h4>
        <p className="text-xs text-muted-foreground mb-2">
          {achievement.description}
        </p>
        <div className="text-xs">
          <span className={achievement.unlocked ? 'text-game-gold' : 'text-gray-500'}>
            {achievement.progress}/{achievement.requirement}
          </span>
        </div>
        {achievement.unlocked && (
          <Badge className="mt-2 bg-game-gold text-black text-xs">
            Unlocked!
          </Badge>
        )}
      </div>
    </div>
  );
};
