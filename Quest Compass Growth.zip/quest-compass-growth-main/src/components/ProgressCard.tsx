
import { Card } from '@/components/ui/card';
import { UserProgress } from '../types/game';

interface ProgressCardProps {
  progress: UserProgress;
}

export const ProgressCard = ({ progress }: ProgressCardProps) => {
  const xpToNextLevel = (progress.level * 100) - progress.totalXP;
  const currentLevelProgress = progress.totalXP % 100;

  return (
    <Card className="glass-card p-6">
      <div className="text-center mb-6">
        <h2 className="text-3xl font-bold gradient-text mb-2">
          Level {progress.level}
        </h2>
        <p className="text-muted-foreground">
          {progress.totalXP} XP Total
        </p>
      </div>

      <div className="space-y-4">
        {/* Level Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progress to Level {progress.level + 1}</span>
            <span>{currentLevelProgress}/100 XP</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-3">
            <div 
              className="xp-gradient h-3 rounded-full transition-all duration-500 relative overflow-hidden"
              style={{ width: `${currentLevelProgress}%` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-30 animate-pulse" />
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4 pt-4">
          <div className="text-center p-3 bg-game-purple/20 rounded-lg">
            <div className="text-2xl font-bold text-game-purple">
              {progress.dailyXP}
            </div>
            <div className="text-xs text-muted-foreground">Daily XP</div>
          </div>
          
          <div className="text-center p-3 bg-game-gold/20 rounded-lg">
            <div className="text-2xl font-bold text-game-gold">
              {progress.completedHabitsToday}
            </div>
            <div className="text-xs text-muted-foreground">Completed Today</div>
          </div>
          
          <div className="text-center p-3 bg-game-green/20 rounded-lg">
            <div className="text-2xl font-bold text-game-green">
              {progress.currentStreak}
            </div>
            <div className="text-xs text-muted-foreground">Current Streak</div>
          </div>
          
          <div className="text-center p-3 bg-game-red/20 rounded-lg">
            <div className="text-2xl font-bold text-game-red">
              {progress.longestStreak}
            </div>
            <div className="text-xs text-muted-foreground">Best Streak</div>
          </div>
        </div>
      </div>
    </Card>
  );
};
