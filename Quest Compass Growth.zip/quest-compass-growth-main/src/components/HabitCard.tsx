import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, Star, Edit, Undo2, BarChart3 } from 'lucide-react';
import { Habit, Discipline } from '../types/game';
import { EditHabitForm } from './EditHabitForm';
import { HabitStats } from './HabitStats';

interface HabitCardProps {
  habit: Habit;
  disciplines: Discipline[];
  onComplete: (habitId: string) => void;
  onUncomplete: (habitId: string) => void;
  onEdit: (habit: Habit) => void;
  onDelete: (habitId: string) => void;
  onUpdateCompletion?: (habitId: string, date: string, completed: boolean) => void;
}

export const HabitCard = ({ 
  habit, 
  disciplines, 
  onComplete, 
  onUncomplete, 
  onEdit, 
  onDelete,
  onUpdateCompletion 
}: HabitCardProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [showStats, setShowStats] = useState(false);

  const getDifficultyColor = (difficulty: Habit['difficulty']) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'hard': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getDisciplineColors = (disciplineIds: string[]) => {
    return disciplineIds.map(id => {
      const discipline = disciplines.find(d => d.id === id);
      return discipline?.color || '#666';
    });
  };

  const handleEdit = (updatedHabit: Habit) => {
    onEdit(updatedHabit);
    setIsEditing(false);
  };

  if (isEditing) {
    return (
      <EditHabitForm
        habit={habit}
        disciplines={disciplines}
        onSaveHabit={handleEdit}
        onCancel={() => setIsEditing(false)}
      />
    );
  }

  return (
    <div className="space-y-4">
      <Card className="glass-card p-4 hover:bg-card/20 transition-all duration-300 group">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="font-semibold text-lg text-white group-hover:text-game-purple transition-colors">
              {habit.name}
            </h3>
            {habit.description && (
              <p className="text-sm text-muted-foreground mt-1">{habit.description}</p>
            )}
          </div>
          
          <div className="flex items-center gap-2 ml-4">
            <Badge className={`${getDifficultyColor(habit.difficulty)} text-white text-xs px-2 py-1`}>
              {habit.difficulty.toUpperCase()}
            </Badge>
            <div className="flex items-center gap-1 text-game-gold">
              <Star className="w-4 h-4" />
              <span className="text-sm font-medium">+{habit.xpReward}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between mb-3">
          <div className="flex gap-1">
            {getDisciplineColors(habit.disciplines).map((color, index) => (
              <div
                key={index}
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
          
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">Streak:</span>
            <span className="text-game-gold font-semibold flex items-center gap-1">
              🔥 {habit.streak}
            </span>
          </div>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={() => habit.completedToday ? onUncomplete(habit.id) : onComplete(habit.id)}
            className={`flex-1 ${
              habit.completedToday
                ? 'bg-green-600 hover:bg-green-700'
                : 'bg-game-purple hover:bg-game-purple/80'
            } transition-all duration-300`}
          >
            {habit.completedToday ? (
              <>
                <Undo2 className="w-4 h-4 mr-2" />
                Undo
              </>
            ) : (
              <>
                <Check className="w-4 h-4 mr-2" />
                Complete
              </>
            )}
          </Button>
          
          <Button
            onClick={() => setShowStats(!showStats)}
            variant="outline"
            size="sm"
            className="border-white/20 hover:bg-white/5"
          >
            <BarChart3 className="w-4 h-4" />
          </Button>
          
          <Button
            onClick={() => setIsEditing(true)}
            variant="outline"
            size="sm"
            className="border-white/20 hover:bg-white/5"
          >
            <Edit className="w-4 h-4" />
          </Button>
          
          <Button
            onClick={() => onDelete(habit.id)}
            variant="outline"
            size="sm"
            className="text-red-400 border-red-400/30 hover:bg-red-400/10"
          >
            Delete
          </Button>
        </div>
      </Card>
      
      {showStats && <HabitStats habit={habit} onUpdateCompletion={onUpdateCompletion} />}
    </div>
  );
};
