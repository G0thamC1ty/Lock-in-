
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, X } from 'lucide-react';
import { Habit } from '../types/game';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface HabitCalendarEditorProps {
  habit: Habit;
  onClose: () => void;
  onUpdateCompletion?: (habitId: string, date: string, completed: boolean) => void;
}

export const HabitCalendarEditor = ({ habit, onClose, onUpdateCompletion }: HabitCalendarEditorProps) => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>();
  // Use local state for instant UI feedback
  const [localCompletedDates, setLocalCompletedDates] = useState<Set<string>>(new Set(habit.completedDates));
  const { toast } = useToast();

  // Sync with passed habit when it changes
  useEffect(() => {
    console.log('Habit changed, updating local state:', habit.completedDates);
    setLocalCompletedDates(new Set(habit.completedDates));
  }, [habit.completedDates, habit.id]);

  const isDateCompleted = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    return localCompletedDates.has(dateString);
  };

  const handleDateSelect = (date: Date | undefined) => {
    setSelectedDate(date);
    console.log('Date selected:', date);
  };

  const isFuture = (date: Date) => {
    const today = new Date();
    today.setHours(23, 59, 59, 999); // End of today
    return date > today;
  };

  const toggleCompletion = () => {
    console.log('Toggle completion called', { selectedDate, onUpdateCompletion });
    
    if (!selectedDate) {
      console.log('No date selected');
      toast({
        description: "Please select a date first.",
        duration: 2000,
      });
      return;
    }

    if (!onUpdateCompletion) {
      console.log('No onUpdateCompletion function provided');
      toast({
        description: "Unable to update completion. Please try again.",
        duration: 2000,
      });
      return;
    }
    
    // Don't allow marking future dates
    if (isFuture(selectedDate)) {
      console.log('Attempting to mark future date');
      toast({
        description: "Cannot mark future dates as completed.",
        duration: 2000,
      });
      return;
    }

    const dateString = selectedDate.toISOString().split('T')[0];
    const isCompleted = isDateCompleted(selectedDate);
    const newCompletionState = !isCompleted;

    console.log('Toggling completion for:', {
      habitId: habit.id,
      date: dateString,
      currentlyCompleted: isCompleted,
      newState: newCompletionState
    });

    // Update local state immediately for instant feedback
    setLocalCompletedDates(prev => {
      const newSet = new Set(prev);
      if (newCompletionState) {
        newSet.add(dateString);
      } else {
        newSet.delete(dateString);
      }
      console.log('Updated local state from', Array.from(prev), 'to', Array.from(newSet));
      return newSet;
    });

    // Call the parent update function
    try {
      onUpdateCompletion(habit.id, dateString, newCompletionState);
      console.log('Called onUpdateCompletion successfully');
      
      toast({
        description: newCompletionState
          ? "Marked as completed."
          : "Marked as incomplete.",
        duration: 1500,
      });
    } catch (error) {
      console.error('Error calling onUpdateCompletion:', error);
      toast({
        description: "Failed to update completion. Please try again.",
        duration: 2000,
      });
      
      // Revert local state on error
      setLocalCompletedDates(prev => {
        const revertSet = new Set(prev);
        if (newCompletionState) {
          revertSet.delete(dateString);
        } else {
          revertSet.add(dateString);
        }
        return revertSet;
      });
    }
  };

  const modifiers = {
    completed: (date: Date) => isDateCompleted(date),
  };
  const modifiersStyles = {
    completed: {
      backgroundColor: '#10B981',
      color: 'white',
    },
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">
            Edit Completions for {habit.name}
          </DialogTitle>
          <DialogDescription>
            Tap a date in the calendar to mark it as completed or incomplete.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={handleDateSelect}
            modifiers={modifiers}
            modifiersStyles={modifiersStyles}
            disabled={(date) => isFuture(date)}
            className={cn("rounded-md border pointer-events-auto")}
          />
          {selectedDate && (
            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div>
                <p className="font-medium">
                  {selectedDate.toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant={isDateCompleted(selectedDate) ? "default" : "outline"}>
                    {isDateCompleted(selectedDate) ? (
                      <>
                        <Check className="w-3 h-3 mr-1" />
                        Completed
                      </>
                    ) : (
                      <>
                        <X className="w-3 h-3 mr-1" />
                        Not Completed
                      </>
                    )}
                  </Badge>
                </div>
              </div>
              <Button
                onClick={toggleCompletion}
                variant={isDateCompleted(selectedDate) ? "destructive" : "default"}
                size="sm"
                disabled={isFuture(selectedDate)}
                className={isFuture(selectedDate) ? 'opacity-40 cursor-not-allowed' : ''}
              >
                {isDateCompleted(selectedDate) ? 'Mark Incomplete' : 'Mark Complete'}
              </Button>
            </div>
          )}
          <div className="text-sm text-muted-foreground text-center">
            Select a date to mark it as completed or incomplete
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
