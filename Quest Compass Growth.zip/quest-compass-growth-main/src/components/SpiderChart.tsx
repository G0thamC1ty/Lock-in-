
import { useEffect, useRef } from 'react';
import { Discipline } from '../types/game';

interface SpiderChartProps {
  disciplines: Discipline[];
  size?: number;
}

export const SpiderChart = ({ disciplines, size = 300 }: SpiderChartProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const centerX = size / 2;
    const centerY = size / 2;
    const radius = size / 2 - 40;
    const numSides = disciplines.length;

    // Clear canvas
    ctx.clearRect(0, 0, size, size);

    // Draw background grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 1;

    for (let i = 1; i <= 5; i++) {
      const gridRadius = (radius * i) / 5;
      ctx.beginPath();
      for (let j = 0; j < numSides; j++) {
        const angle = (j * 2 * Math.PI) / numSides - Math.PI / 2;
        const x = centerX + gridRadius * Math.cos(angle);
        const y = centerY + gridRadius * Math.sin(angle);
        
        if (j === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.closePath();
      ctx.stroke();
    }

    // Draw axes
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    for (let i = 0; i < numSides; i++) {
      const angle = (i * 2 * Math.PI) / numSides - Math.PI / 2;
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);
      
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(x, y);
      ctx.stroke();
    }

    // Draw data polygon
    if (disciplines.some(d => d.totalXP > 0)) {
      ctx.fillStyle = 'rgba(139, 92, 246, 0.3)';
      ctx.strokeStyle = 'rgba(139, 92, 246, 0.8)';
      ctx.lineWidth = 2;
      
      ctx.beginPath();
      disciplines.forEach((discipline, i) => {
        const angle = (i * 2 * Math.PI) / numSides - Math.PI / 2;
        const value = Math.min(discipline.totalXP / 100, 1); // Normalize to 0-1
        const pointRadius = radius * value;
        const x = centerX + pointRadius * Math.cos(angle);
        const y = centerY + pointRadius * Math.sin(angle);
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Draw data points
      disciplines.forEach((discipline, i) => {
        const angle = (i * 2 * Math.PI) / numSides - Math.PI / 2;
        const value = Math.min(discipline.totalXP / 100, 1);
        const pointRadius = radius * value;
        const x = centerX + pointRadius * Math.cos(angle);
        const y = centerY + pointRadius * Math.sin(angle);
        
        ctx.fillStyle = discipline.color;
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, 2 * Math.PI);
        ctx.fill();
      });
    }

    // Draw labels
    ctx.fillStyle = 'white';
    ctx.font = '12px sans-serif';
    ctx.textAlign = 'center';
    
    disciplines.forEach((discipline, i) => {
      const angle = (i * 2 * Math.PI) / numSides - Math.PI / 2;
      const labelRadius = radius + 20;
      const x = centerX + labelRadius * Math.cos(angle);
      const y = centerY + labelRadius * Math.sin(angle);
      
      ctx.fillText(discipline.name, x, y + 4);
      
      // Draw level below name
      ctx.fillStyle = discipline.color;
      ctx.fillText(`Lv.${discipline.level}`, x, y + 18);
      ctx.fillStyle = 'white';
    });

  }, [disciplines, size]);

  return (
    <div className="flex flex-col items-center">
      <canvas
        ref={canvasRef}
        width={size}
        height={size}
        className="border border-white/10 rounded-lg bg-black/20"
      />
      <p className="text-sm text-muted-foreground mt-2 text-center">
        Spider chart shows your progress across all disciplines
      </p>
    </div>
  );
};
