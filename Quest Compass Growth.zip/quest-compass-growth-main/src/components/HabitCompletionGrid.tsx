import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar as CalendarIcon } from 'lucide-react';
import { Habit } from '../types/game';
import { HabitCalendarEditor } from './HabitCalendarEditor';
import { useState } from 'react';

interface HabitCompletionGridProps {
  habit: Habit;
  onUpdateCompletion?: (habitId: string, date: string, completed: boolean) => void;
}

export const HabitCompletionGrid = ({ habit, onUpdateCompletion }: HabitCompletionGridProps) => {
  const [showCalendarEditor, setShowCalendarEditor] = useState(false);

  const completedDates = new Set(habit.completedDates);

  const isCompleted = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    return completedDates.has(dateString);
  };

  const getDateLabel = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  // Create a horizontal grid by weeks (53 columns of 7 rows each)
  const createHorizontalGrid = () => {
    const grid = [];
    const totalWeeks = 53;
    
    // Get today's date
    const today = new Date();
    
    // Find the most recent Sunday (start of the week)
    const mostRecentSunday = new Date(today);
    mostRecentSunday.setDate(today.getDate() - today.getDay());
    mostRecentSunday.setHours(0, 0, 0, 0);
    
    // Create 7 rows (one for each day of the week: Sunday through Saturday)
    for (let dayOfWeek = 0; dayOfWeek < 7; dayOfWeek++) {
      const row = [];
      for (let week = 0; week < totalWeeks; week++) {
        const date = new Date(mostRecentSunday);
        // Go back in time for each week, then add the day of week
        date.setDate(mostRecentSunday.getDate() - ((totalWeeks - 1 - week) * 7) + dayOfWeek);
        row.push(date);
      }
      grid.push(row);
    }
    
    return grid;
  };

  const horizontalGrid = createHorizontalGrid();
  const dayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <Card className="glass-card p-4">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold text-white">{habit.name} - Year Overview</h4>
        <div className="flex items-center gap-3">
          <div className="text-sm text-muted-foreground">
            {habit.completedDates.length} completions this year
          </div>
          <Button
            onClick={() => setShowCalendarEditor(true)}
            variant="outline"
            size="sm"
            className="border-white/20 hover:bg-white/5"
          >
            <CalendarIcon className="w-4 h-4 mr-2" />
            Edit
          </Button>
        </div>
      </div>
      
      {/* Horizontal scrollable container */}
      <div className="overflow-x-auto">
        <div className="flex gap-1 min-w-max">
          {/* Day labels column */}
          <div className="flex flex-col gap-1 mr-2">
            <div className="h-3 mb-1"></div> {/* Spacer for month labels */}
            {dayLabels.map((day) => (
              <div key={day} className="h-3 flex items-center">
                <span className="text-xs text-muted-foreground w-8 text-right">
                  {day}
                </span>
              </div>
            ))}
          </div>
          
          {/* Grid columns */}
          {horizontalGrid[0].map((_, weekIndex) => (
            <div key={weekIndex} className="flex flex-col gap-1">
              {/* Month label for first week of each month */}
              <div className="h-3 mb-1 flex items-center justify-center">
                {weekIndex === 0 || horizontalGrid[0][weekIndex].getDate() <= 7 ? (
                  <span className="text-xs text-muted-foreground">
                    {horizontalGrid[0][weekIndex].toLocaleDateString('en-US', { month: 'short' })}
                  </span>
                ) : null}
              </div>
              
              {/* Days in this week */}
              {horizontalGrid.map((row, dayIndex) => {
                const date = row[weekIndex];
                const completed = isCompleted(date);
                const isToday = date.toDateString() === new Date().toDateString();
                const isFuture = date > new Date();
                
                return (
                  <div
                    key={`${weekIndex}-${dayIndex}`}
                    className={`
                      w-3 h-3 rounded-sm transition-all duration-200 hover:scale-110
                      ${completed 
                        ? 'bg-game-green shadow-sm' 
                        : isFuture 
                          ? 'bg-white/5' 
                          : 'bg-white/10 hover:bg-white/20'
                      }
                      ${isToday ? 'ring-2 ring-game-blue ring-offset-1 ring-offset-background' : ''}
                      ${isFuture ? 'opacity-30' : 'cursor-pointer'}
                    `}
                    title={`${getDateLabel(date)}${completed ? ' - Completed' : ' - Not completed'}`}
                  />
                );
              })}
            </div>
          ))}
        </div>
      </div>
      
      <div className="flex items-center justify-between mt-4 text-xs text-muted-foreground">
        <span>Less</span>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 rounded-sm bg-white/10" />
          <div className="w-2 h-2 rounded-sm bg-game-green/30" />
          <div className="w-2 h-2 rounded-sm bg-game-green/60" />
          <div className="w-2 h-2 rounded-sm bg-game-green" />
        </div>
        <span>More</span>
      </div>

      {showCalendarEditor && (
        <HabitCalendarEditor
          habit={habit}
          onClose={() => setShowCalendarEditor(false)}
          onUpdateCompletion={onUpdateCompletion}
        />
      )}
    </Card>
  );
};
