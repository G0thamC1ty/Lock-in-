
import { Card } from '@/components/ui/card';
import { Habit } from '../types/game';
import { Calendar, BarChart3 } from 'lucide-react';
import { HabitCompletionGrid } from './HabitCompletionGrid';

interface HabitStatsProps {
  habit: Habit;
  onUpdateCompletion?: (habitId: string, date: string, completed: boolean) => void;
}

export const HabitStats = ({ habit, onUpdateCompletion }: HabitStatsProps) => {
  const calculateStats = () => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();
    
    // Get start of current week (Sunday)
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());
    startOfWeek.setHours(0, 0, 0, 0);
    
    // Get start of current month
    const startOfMonth = new Date(currentYear, currentMonth, 1);
    
    // Get start of current year
    const startOfYear = new Date(currentYear, 0, 1);
    
    const completedDates = habit.completedDates.map(date => new Date(date));
    
    const weeklyCompletions = completedDates.filter(date => date >= startOfWeek).length;
    const monthlyCompletions = completedDates.filter(date => date >= startOfMonth).length;
    const yearlyCompletions = completedDates.filter(date => date >= startOfYear).length;
    const totalCompletions = completedDates.length;
    
    return {
      weeklyCompletions,
      monthlyCompletions,
      yearlyCompletions,
      totalCompletions
    };
  };

  const stats = calculateStats();

  return (
    <div className="space-y-4">
      {/* Visual Grid Tracker */}
      <HabitCompletionGrid habit={habit} onUpdateCompletion={onUpdateCompletion} />
      
      {/* Stats Summary */}
      <Card className="glass-card p-4">
        <div className="flex items-center gap-2 mb-3">
          <BarChart3 className="w-4 h-4 text-game-purple" />
          <h4 className="font-semibold text-white">Completion Stats</h4>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          <div className="text-center p-2 bg-game-blue/20 rounded-lg">
            <div className="text-lg font-bold text-game-blue">{stats.weeklyCompletions}</div>
            <div className="text-xs text-muted-foreground">This Week</div>
          </div>
          
          <div className="text-center p-2 bg-game-green/20 rounded-lg">
            <div className="text-lg font-bold text-game-green">{stats.monthlyCompletions}</div>
            <div className="text-xs text-muted-foreground">This Month</div>
          </div>
          
          <div className="text-center p-2 bg-game-gold/20 rounded-lg">
            <div className="text-lg font-bold text-game-gold">{stats.yearlyCompletions}</div>
            <div className="text-xs text-muted-foreground">This Year</div>
          </div>
          
          <div className="text-center p-2 bg-game-purple/20 rounded-lg">
            <div className="text-lg font-bold text-game-purple">{stats.totalCompletions}</div>
            <div className="text-xs text-muted-foreground">All Time</div>
          </div>
        </div>
      </Card>
    </div>
  );
};
