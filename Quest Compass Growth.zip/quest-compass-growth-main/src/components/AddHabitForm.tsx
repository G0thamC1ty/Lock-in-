
import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Habit, Discipline } from '../types/game';

interface AddHabitFormProps {
  disciplines: Discipline[];
  onAddHabit: (habit: Omit<Habit, 'id' | 'streak' | 'completedToday' | 'completedDates' | 'createdAt' | 'xpReward'>) => void;
  onCancel: () => void;
}

export const AddHabitForm = ({ disciplines, onAddHabit, onCancel }: AddHabitFormProps) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [difficulty, setDifficulty] = useState<Habit['difficulty']>('medium');
  const [frequency, setFrequency] = useState<string>('daily');
  const [selectedDisciplines, setSelectedDisciplines] = useState<string[]>([]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || selectedDisciplines.length === 0) return;

    // Convert frequency string back to the proper Habit frequency type
    const habitFrequency: Habit['frequency'] = frequency === 'daily' || frequency === 'weekly' ? frequency : 'daily';

    onAddHabit({
      name: name.trim(),
      description: description.trim(),
      difficulty,
      frequency: habitFrequency,
      disciplines: selectedDisciplines
    });

    // Reset form
    setName('');
    setDescription('');
    setDifficulty('medium');
    setFrequency('daily');
    setSelectedDisciplines([]);
  };

  const toggleDiscipline = (disciplineId: string) => {
    setSelectedDisciplines(prev => 
      prev.includes(disciplineId)
        ? prev.filter(id => id !== disciplineId)
        : [...prev, disciplineId]
    );
  };

  const getDifficultyXP = (diff: Habit['difficulty']) => {
    switch (diff) {
      case 'easy': return 1;
      case 'medium': return 3;
      case 'hard': return 5;
      default: return 1;
    }
  };

  return (
    <Card className="glass-card p-6">
      <h3 className="text-xl font-semibold gradient-text mb-4">Add New Habit</h3>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="name">Habit Name</Label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Morning meditation"
            className="bg-white/5 border-white/10"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description (optional)</Label>
          <Textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Why is this habit important to you?"
            className="bg-white/5 border-white/10"
            rows={3}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Difficulty</Label>
            <Select value={difficulty} onValueChange={(value: Habit['difficulty']) => setDifficulty(value)}>
              <SelectTrigger className="bg-white/5 border-white/10">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="easy">Easy (+{getDifficultyXP('easy')} XP)</SelectItem>
                <SelectItem value="medium">Medium (+{getDifficultyXP('medium')} XP)</SelectItem>
                <SelectItem value="hard">Hard (+{getDifficultyXP('hard')} XP)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Frequency</Label>
            <Select value={frequency} onValueChange={(value: string) => setFrequency(value)}>
              <SelectTrigger className="bg-white/5 border-white/10">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-3">
          <Label>Assign to Disciplines</Label>
          <div className="flex flex-wrap gap-2">
            {disciplines.map(discipline => (
              <Badge
                key={discipline.id}
                variant={selectedDisciplines.includes(discipline.id) ? "default" : "outline"}
                className={`cursor-pointer transition-all ${
                  selectedDisciplines.includes(discipline.id)
                    ? 'bg-game-purple hover:bg-game-purple/80'
                    : 'hover:bg-white/10'
                }`}
                onClick={() => toggleDiscipline(discipline.id)}
                style={{
                  backgroundColor: selectedDisciplines.includes(discipline.id) ? discipline.color : undefined,
                  borderColor: discipline.color
                }}
              >
                {discipline.name}
              </Badge>
            ))}
          </div>
          {selectedDisciplines.length === 0 && (
            <p className="text-sm text-red-400">Please select at least one discipline</p>
          )}
        </div>

        <div className="flex gap-3 pt-4">
          <Button 
            type="submit" 
            className="flex-1 bg-game-purple hover:bg-game-purple/80"
            disabled={!name.trim() || selectedDisciplines.length === 0}
          >
            Add Habit
          </Button>
          <Button 
            type="button" 
            variant="outline" 
            onClick={onCancel}
            className="border-white/20 hover:bg-white/5"
          >
            Cancel
          </Button>
        </div>
      </form>
    </Card>
  );
};
